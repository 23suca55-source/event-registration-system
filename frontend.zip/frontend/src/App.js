import React, { useEffect, useState } from "react";

function App() {
  const [events, setEvents] = useState([]);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    eventId: ""
  });
  const [msg, setMsg] = useState("");

  // events load
  useEffect(() => {
    fetch("http://localhost:8080/api/events")
      .then(res => res.json())
      .then(data => setEvents(data));
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const submitForm = (e) => {
    e.preventDefault();

    fetch("http://localhost:8080/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    })
      .then(res => res.json())
      .then(() => {
        setMsg("✅ Registration Successful");
        setForm({ name: "", email: "", phone: "", eventId: "" });
      });
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>📅 Events List</h2>
      <ul>
        {events.map(e => (
          <li key={e.id}>
            {e.name} – {e.date} – {e.location}
          </li>
        ))}
      </ul>

      <hr />

      <h2>📝 Register for Event</h2>
      <form onSubmit={submitForm}>
        <input
          name="name"
          placeholder="Name"
          value={form.name}
          onChange={handleChange}
          required
        /><br /><br />

        <input
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
        /><br /><br />

        <input
          name="phone"
          placeholder="Phone"
          value={form.phone}
          onChange={handleChange}
          required
        /><br /><br />

        <select
          name="eventId"
          value={form.eventId}
          onChange={handleChange}
          required
        >
          <option value="">Select Event</option>
          {events.map(e => (
            <option key={e.id} value={e.id}>
              {e.name}
            </option>
          ))}
        </select><br /><br />

        <button type="submit">Register</button>
      </form>

      <h3>{msg}</h3>
    </div>
  );
}

export default App;
